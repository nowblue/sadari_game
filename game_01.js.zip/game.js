document.addEventListener('DOMContentLoaded', () => {
    const character = document.querySelector('.char');
    const container = document.querySelector('main');
    const building = document.querySelector('.building_a');
    const hole = document.querySelector('.hole');
    const pole = document.querySelector('.pole_a');

    // 캐릭터를 이동시키는 함수
    function moveCharacter(x, y) {
        character.style.left = x + 'px';
        character.style.top = y + 'px';

        checkOverlap(); // 캐릭터가 이동할 때마다 겹치는지 확인
    }

    // 캐릭터와 여러 요소의 위치가 겹치는지 확인하는 함수
    function checkOverlap() {
        const charRect = character.getBoundingClientRect();
        const buildingRect = building.getBoundingClientRect();
        const holeRect = hole.getBoundingClientRect();
        const poleRect = pole.getBoundingClientRect();

        // 기본 투명도를 1로 설정
        character.style.opacity = 1;

        // 겹치는지 확인
        if (
            (charRect.right > buildingRect.left && charRect.left < buildingRect.right &&
             charRect.bottom > buildingRect.top && charRect.top < buildingRect.bottom) ||
            (charRect.right > holeRect.left && charRect.left < holeRect.right &&
             charRect.bottom > holeRect.top && charRect.top < holeRect.bottom) ||
            (charRect.right > poleRect.left && charRect.left < poleRect.right &&
             charRect.bottom > poleRect.top && charRect.top < poleRect.bottom)
        ) {
            // 겹친다면 투명도 50%
            character.style.opacity = 0.5;
        }
    }

    // 키보드 입력에 따라 캐릭터를 이동시키고 방향을 변경하는 함수
    document.addEventListener('keydown', (event) => {
        let newX = parseInt(character.style.left) || 0;
        let newY = parseInt(character.style.top) || 0;

        // 방향 설정
        let currentDirection = character.dataset.direction;

        if (event.key === 'ArrowLeft') {
            newX -= 10;
            currentDirection = 'left';
        } else if (event.key === 'ArrowRight') {
            newX += 10;
            currentDirection = 'right';
        } else if (event.key === 'ArrowUp') {
            newY -= 10;
            currentDirection = 'up';
        } else if (event.key === 'ArrowDown') {
            newY += 10;
            currentDirection = 'down';
        }

        // 방향 변경
        character.dataset.direction = currentDirection;

        // 걷기 애니메이션 시작
        character.dataset.walking = 'true';

        // 경계를 벗어나지 않도록 조정
        newX = Math.max(newX, 0);
        newX = Math.min(newX, container.clientWidth - character.clientWidth);
        newY = Math.max(newY, 0);
        newY = Math.min(newY, container.clientHeight - character.clientHeight);

        // 캐릭터 이동
        moveCharacter(newX, newY);
    });

    // 키를 떼면 걷기 애니메이션 중지
    document.addEventListener('keyup', () => {
        character.dataset.walking = 'false';
    });
});
